#ifndef _CHECK_CHECK_STDINT_H
#define _CHECK_CHECK_STDINT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "check 0.10.0"
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
